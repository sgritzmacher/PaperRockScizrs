//
//  prs_stage2.cpp
//  PaperRockScizrs
//
//  Created by Shawn Gritzmacher on 1/23/23.
//  Copyright © 2023 Shawn Gritzmacher. All rights reserved.
//
#if PRS_corrections

#include <stdio.h>
#include <iostream>
#include <time.h>
#include <string>

using namespace std;

constexpr int g_playGame = 1;
constexpr int g_exitGame = 2;


int main()
{
    // main scenarios
    srand((unsigned)time(0));
    
    cout << "Welcome to Paper Rock Scissors " << endl;
    cout << "Please choose 1 to play or 2 to exit " << endl;
    int userSelect;
    cin >> userSelect;
    
    switch(userSelect)
    {
        case g_playGame:
        {
            //game generates its play.
            int prsComp = 1 + rand() % 3;
            
            //present to user now
            cout << "Beat the computer at the game of Paper, Rock, Scissors" << endl;
            cout << " Make a choice by typing a number" << endl;
            cout << " 1. Paper " << endl;
            cout << " 2. Rock " << endl;
            cout << " 3. Scissors " << endl;
            int userChoice;
            cin >> userChoice;
            
            
            // PAPER -
            // paper to paper = tie,
            if(userChoice == prsComp)
            {
                
                
                if(userChoice == 1)
                {
                   cout << " Tie. You both had Paper. " << endl;
                }
                if(userChoice == 2)
                {
                    cout << " Tie. You both had Rock. " << endl;
                }
                else
                {
                    cout << " Tie. You both had Scissors. " << endl;
                }
            }
        
            // paper less than rock. paper less than scissors.  rock less than scissors
            if(userChoice < prsComp)
            {
                
                // paper < rock
                if(userChoice == 2)
                {
                
                  cout << " You chose Rock! You win! Rock smashes scissors. " << endl;
                }
                if(userChoice == 1)
                {
                   cout << " You chose Paper. You lose. Scissors cuts paper. " << endl;
                }
                
            }
            
            //rock to paper. rock to scissors
            if(userChoice > prsComp)
            
            {
                if(userChoice == 2)
                {
                    cout << "You chose Rock.  You lose.  Paper Wraps rock." << endl;
                }
                if(userChoice == 3)
                {
                    cout << "You chose Scissors. You win!  Scissors cuts paper." << endl;
                }
            }
          
            break;
        
        }
        case g_exitGame:
        {
            cout << " Exit " << endl;
            
        }
        default:
        {
            cout << "Invalid information. " << endl;
        }
    }
    
}


#endif


